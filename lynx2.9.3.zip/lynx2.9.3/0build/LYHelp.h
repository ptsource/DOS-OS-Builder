/*
 * $LynxId: LYHelp.hin,v 1.4 2008/01/10 23:26:53 tom Exp $
 * vile:cmode
 */
/* definitions for help files */

#ifndef LYHELP_H
#define LYHELP_H

#define ALT_EDIT_HELP		"keystrokes/alt_edit_help.html"
#define BASHLIKE_EDIT_HELP	"keystrokes/bashlike_edit_help.html"
#define COOKIE_JAR_HELP		"Lynx_users_guide.html#Cookies"
#define CACHE_JAR_HELP		"Lynx_users_guide.html#Cache"
#define CURRENT_KEYMAP_HELP	"keystrokes/keystroke_help.html"
#define DIRED_MENU_HELP		"keystrokes/dired_help.html"
#define EDIT_HELP		"keystrokes/edit_help.html"
#define DOWNLOAD_OPTIONS_HELP	"Lynx_users_guide.html#RemoteSource"
#define HISTORY_PAGE_HELP	"keystrokes/history_help.html"
#define LIST_PAGE_HELP		"keystrokes/follow_help.html"
#define LYNXCFG_HELP		"lynx.cfg"
#define OPTIONS_HELP		"keystrokes/option_help.html"
#define PRINT_OPTIONS_HELP	"keystrokes/print_help.html"
#define UPLOAD_OPTIONS_HELP	"Lynx_users_guide.html#DirEd"
#define VISITED_LINKS_HELP	"keystrokes/visited_help.html"

#endif /* LYHELP_H */
